
#include <stdio.h>
#include "ukf.h"

Matrix state_func (Matrix x)	// nonlinear state equations
{
	//Matrix state(3,1);
	//state(1,1) = x(2,1);
	//state(2,1) = x(3,1);
	//state(3,1) = 0.05*x(1,1)*(x(2,1)+x(3,1));
	//return state;

	Matrix state(3,1);
	state(1,1) = x(1,1);
	state(2,1) = x(2,1);
	state(3,1) = x(3,1);
	return state;
}

Matrix measurement_func (Matrix x)	// measurement equation
{
	//Matrix measurement(1,1);
	//measurement(1,1) = x(1,1);
	//return measurement;

	Matrix measurement(3,1);
	measurement(1,1) = x(1,1);
	measurement(2,1) = x(2,1);
	measurement(3,1) = x(3,1);
	return measurement;
}

int main ()
{
	int n=3;
	int m=3;

	Matrix s(3,1);	// initial state
	s(1,1) = 0;
	s(2,1) = 0;
	s(3,1) = 1;
	Matrix x = s+0.01; /*x=s+q*randn(3,1);*/	// initial state with noise	/* Matrix x = s+0.01; -> add to all element */
	SymmetricMatrix P;
	P << IdentityMatrix(n);	// initial state covraiance
	unsigned int N=20;                                     // total dynamic steps
	Matrix xV(n,N);          //estmate        // allocate memory
	Matrix sV(n,N);          //actual
	Matrix zV(m,N);

	for (unsigned int k=1; k<=N; k++)
	{
		Matrix z = measurement_func(s) + 0.02; /*z=s+r*randn;*/                     // measurments
		sV.Column(k) = s;                             // save actual state
		zV.Column(k) = z;                             // save measurment
		ukf(x, P, z);
		xV.Column(k) = x;                            // save estimate
		s = state_func(s) + 0.03;                // update process
	}

	printf("sV:\n");
	for (unsigned int rr=1; rr<=n; rr++)
	{
		for (unsigned int k=1; k<=N; k++)
			printf("%.4f ", sV(rr,k));
		printf("\n");
	}
	printf("\nxV:\n");
	for (unsigned int rr=1; rr<=n; rr++)
	{
		for (unsigned int k=1; k<=N; k++)
			printf("%.4f ", xV(rr,k));
		printf("\n");
	}
	printf("\n\P:\n");
	for (unsigned int rr=1; rr<=n; rr++)
	{
		for (unsigned int cc=1; cc<=n; cc++)
			printf("%.4f ", P(rr,cc));
		printf("\n");
	}

	system("pause");
	return 1;
}

#include <math.h>
#include "NEWMAT.H"

/* ----------------------- initialize ----------------------- */
const int n=3;      //number of state
const int m=3;      //number of measurement
const int L=2*n+1;
const double q=0.1;    //std of process 
const double r=0.1;    //std of measurement
const Matrix Q = (q*q) * IdentityMatrix(n);	// covariance of process
const Matrix R = (r*r) * IdentityMatrix(m);	// covariance of measurement

Matrix state_function (Matrix x)	// nonlinear state equations
{
	//Matrix state(3,1);
	//state(1,1) = x(2,1);
	//state(2,1) = x(3,1);
	//state(3,1) = 0.05*x(1,1)*(x(2,1)+x(3,1));
	//return state;

	Matrix state(3,1);
	state(1,1) = x(1,1);
	state(2,1) = x(2,1);
	state(3,1) = x(3,1);
	return state;
}

Matrix measurement_function (Matrix x)	// measurement equation
{
	//Matrix measurement(1,1);
	//measurement(1,1) = x(1,1);
	//return measurement;

	Matrix measurement(3,1);
	measurement(1,1) = x(1,1);
	measurement(2,1) = x(2,1);
	measurement(3,1) = x(3,1);
	return measurement;
}
/* ---------------------------------------------------------- */

ReturnMatrix sigmas(const ColumnVector& x, SymmetricMatrix& P, double c);

void ukf( Matrix &x, SymmetricMatrix& P, const Matrix& z) /* requires state_fun and meas_fun */
{
	double alpha = 1e-3;                                 //default, tunable
	double ki = 0.0;                                       //default, tunable
	double beta = 2.0;                                     //default, tunable
	double lambda = (alpha*alpha)*(n+ki)-n;              //scaling factor
	double c = n+lambda;                                 //scaling factor

	/* weight equations are found in the upper part of http://www.cslu.ogi.edu/nsel/ukf/node6.html */
	Matrix Wm(1,L);	//weights for means	
	Wm(1,1) = lambda/c;
	for (unsigned int k=1; k<=(L-1); k++)
		Wm(1,k+1) = 0.5/c;
	Matrix Wc = Wm;	//weights for covariance
	Wc(1,1) = Wc(1,1)+(1-(alpha*alpha)+beta);
	c = sqrt(c);

	Matrix X = sigmas(x, P, c);	//sigma points around x

	/* unscented transformation (ut) of process */
	Matrix x1(n,1); x1 = 0.0;
	Matrix X1(n,L); X1 = 0.0;
	for(unsigned int k=1; k<=L; k++)
	{
		ColumnVector Xcol(n);
		ColumnVector X1col(n);	/* temp vectors, not used in matlab */

		Xcol = X.Column(k);
		X1col = state_function(Xcol);
		x1 += Wm(1,k) * X1col;
		X1.Column(k) = X1col;
	}
	Matrix X2(n,L);
	for (unsigned int k=1; k<=L; k++)
		X2.Column(k) = X1.Column(k) - x1;
	DiagonalMatrix diagWm(L);
	for(unsigned int k=1; k<=L; k++)
		diagWm(k) = Wm(1,k);
	Matrix P1 = X2 * diagWm * X1.t() + Q;

	/* unscented transformation (ut) of measurements */
	Matrix z1(m,1); z1 = 0.0;
	Matrix Z1(m,L); Z1 = 0.0;
	for(unsigned int k=1; k<=L; k++)
	{
		//ColumnVector Zcol(m);
		ColumnVector X1col(n);
		ColumnVector Z1col(m);	/* temp vectors, not used in matlab */

		X1col = X1.Column(k);
		Z1col = measurement_function(X1col);
		z1 += Wm(1,k) * Z1col;
		Z1.Column(k) = Z1col;
	}
	Matrix Z2(m,L);
	for(unsigned int k=1; k<=L; k++)
		Z2.Column(k) = Z1.Column(k) - z1;
	DiagonalMatrix diagWc(L);
	for(unsigned int k=1; k<=L; k++)
		diagWc(k) = Wc(1,k);
	Matrix P2 = Z2 * diagWc * Z2.t() + R;

	Matrix P12 = X2 * diagWc * Z2.t();                        //transformed cross-covariance 
	Matrix K = P12 * P2.i();
	x = x1+K*(z-z1);                              //state update
	P << P1-K*P12.t();                                //covariance update
}

ReturnMatrix sigmas(const ColumnVector& x, SymmetricMatrix& P, double c)
{
	LowerTriangularMatrix Chol = Cholesky(P);
	Matrix A = c * Chol.t();	/* .t() means transpose */
		
	Matrix X(n,L);
	for(unsigned int k=1; k<=L; k++)
		X.Column(k) = x;
	X.SubMatrix(1,n, 2,2+n-1) += A;
	X.SubMatrix(1,n, 2+n,L) -= A;

	X.Release(); return X;
}
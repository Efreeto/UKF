
#include "UKF.h"

Matrix state_func (Matrix x)	// nonlinear state equations
{
	Matrix state(4,1);
	state(0,0) = x(0,0)+x(2,0);
	state(1,0) = x(1,0)+x(3,0);
	state(2,0) = x(2,0);
	state(3,0) = x(3,0);
	return state;
}

Matrix measurement_func (Matrix x)	// measurement equation
{
	Matrix measurement(2,1);
	measurement(0,0) = x(0,0);
	measurement(1,0) = x(1,0);
	return measurement;
}

int main ()
{
	cout.precision(5);

	int n=4;
	int m=2;
	
	Matrix I4(n,n);	// 4x4 Identity Matrix
	I4(0,0) = 1;	I4(1,1) = 1;	I4(2,2) = 1;	I4(3,3) = 1;
	Matrix I2(m,m);	// 2x2 Identity Matrix
	I2(0,0) = 1;	I2(1,1) = 1;
	
	Matrix s(n,1);	// initial state
	s(0,0) = 1;	s(1,0) = 1;	s(2,0) = 0;	s(3,0) = 0;

	Matrix x = s; /*x=s+q*randn(2,0);*/	// initial state with noise
	const double q=0.1;    //std of process 
	const double r=0.1;    //std of measurement
	Matrix P = I4;	// initial state covraiance
	Matrix Q = (q*q) * I4;	// covariance of process	(size must be nxn)
	Matrix R = (r*r) * I2;	// covariance of measurement (size must be mxm)
	
	unsigned int N=20;	// total dynamic steps
	Matrix xV(n,N);          //estmate        // allocate memory
	Matrix sV(n,N);          //actual
	Matrix zV(m,N);

	for (unsigned int k=0; k<N; k++)
	{
		Matrix z = measurement_func(s);  // measurments
		z += 0.01;	// artificial noise
		for (unsigned int i=0; i<n; i++)
		{
			sV(i,k) = s(i,0);	// save actual state
		}
		for (unsigned int i=0; i<m; i++)
		{
			zV(i,k) = z(i,0);	// save measurement
		}
		ukf(x, P, Q, R, z);
		for (unsigned int i=0; i<n; i++)
		{
			xV(i,k) = x(i,0);	// save estimate
		}
		s = state_func(s);	// update process
		s += 0.01;	// artificial
	}

	cout << "sV:\n" << sV << endl;
	cout << "\nxV:\n" << xV << endl;
	cout << "\nP:\n" << P << endl;

	system("pause");

	/* Application example! */
	//for (unsigned int k=0; k<N; k++)
	//{
	//	Matrix z = [measurements];  // measurment
	//	ukf(x, P, Q, R, z);
	//	Matrix w = measurement_func(x);	// estimated measurement
	//}

	return 1;
}
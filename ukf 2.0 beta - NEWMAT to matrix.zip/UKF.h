
#include "matrix.h"

using namespace std;
using namespace math;
typedef matrix<double> Matrix;

//virtual Matrix state_function (Matrix x);	// nonlinear state equations

void ukf( Matrix& x, Matrix& P, const Matrix Q, const Matrix R, const Matrix z);